iris_data = csvread('iris_data_25X3_train.txt');
num_attributes = size(iris_data,2)-1;
attributes_left = 1:num_attributes;
num_elements = size(iris_data,1);

attribute = get_best_attribute(attributes_left, iris_data);

node_path = [];

classifier = split (iris_data, attributes_left,attribute, node_path);

display(classifier);

accuracy_training_set = test_classifier(classifier, iris_data, attribute);
display(accuracy_training_set);

test_data = csvread('iris_data_25X3_exam.txt');
accuracy_test_set = test_classifier(classifier, test_data, attribute);
display(accuracy_test_set);


test_data150 = csvread('iris.txt');
accuracy_test_set_150 = test_classifier(classifier, test_data150, attribute);
display(accuracy_test_set_150);
